library(bslib)
library(plotly)
library(shinyjs)
library(ggplot2)
library(dplyr)
library(ggstream)
library(shinythemes)
library(shinydashboard)
library(packcircles)
library(ggiraph)
library(stringi)
library(stringr)

pad_legend_title <- function(title, desired_length) {
  str_pad(title, width = desired_length, side = "right", pad = " ")
}

load_and_process_data <- function(person) {
  stream_data <- read.csv(paste0("pliki_csv/streamgraph_", person, ".csv"))
  stream_data$endTime <- as.POSIXct(stream_data$endTime)
  
  genre_data <- read.csv(paste0("pliki_csv/gatunki_", person, ".csv"), encoding = "UTF-8")
  top_data <- read.csv(paste0("pliki_csv/top_10_", person, ".csv"))
  top_genre <- top_data %>% 
    select("genre") %>% 
    head(1)
  
  genre_data <- genre_data %>%
    mutate(msPlayed = as.numeric(msPlayed),
           minutesPlayed = msPlayed / (1000 * 60))
  
  top_time_played <- genre_data %>%
    filter(genre == top_genre[1,]) %>%
    summarise(top_time_played = sum(minutesPlayed))
  
  liczba_gatunkow <- length(unique(genre_data$genre))
  
  set.seed(997)
  artist_data <- read.csv(paste0("pliki_csv/artists_sorted_", person, ".csv"))
  artist_data <- head(artist_data, 100)
  artist_data <- artist_data[sample(nrow(artist_data)), ]
  packing <- circleProgressiveLayout(artist_data$Count, sizetype = 'area')
  artist_data <- cbind(artist_data, packing)
  dat.gg <- circleLayoutVertices(packing, npoints = 70)
  
  return(list(
    top_genre = top_genre,
    stream_data = stream_data,
    genre_data = genre_data,
    top_time_played = top_time_played,
    liczba_gatunkow = liczba_gatunkow,
    artist_data = artist_data,
    dat.gg = dat.gg
  ))
}

martyna <- load_and_process_data("martyna")
zuza <- load_and_process_data("zuza")
gleb <- load_and_process_data("gleb")


ui <- dashboardPage(
  skin = "black",
  dashboardHeader(
    title = "Streaming Data Analysis",
    titleWidth = 300,  # Adjust the title width as needed
    tags$li(
      class = "dropdown",
      tags$style(".main-header {background-color: #333333; color: white;}",
                 '.my-fluid-color-space {background-color: #2E2E2E;}'),
      tags$ul(
        class = "dropdown-menu", 
        tags$li(tags$a(href = "#", "Option 1")),
        tags$li(tags$a(href = "#", "Option 2"))
      )
    )
  ),
  dashboardSidebar(
    collapsed = FALSE,
    selectInput("personInputMartyna", "Select a person:", 
                choices = c("Zuza", "Hleb", "Martyna"), multiple = FALSE)
  ),
  dashboardBody(
    tags$head(
      tags$style(HTML('.content-wrapper {background-color: #2E2E2E;}'))  # Change content background color here
    ),
    fixed = TRUE,
    mainPanel(
      fluidRow(
        h3("Jakich gatunków słuchaliśmy na przestrzeni czasu?", style = "color: white;"),
        plotOutput("stream_plot"),
        style = "background-color: #2E2E2E;",
      ),
      fluidRow(
        valueBoxOutput("liczba_gatunkow_box"),
        valueBoxOutput("top_box"),
        valueBoxOutput("top_time_played_box")
      ),
      fluidRow(
        column(
          selectInput("feature", "Choose Audio Feature", choices = c("Danceability", "Liveness", "Energy", "Valence")),
          girafeOutput("packcircles_plot", width="auto", height = "auto"),
          style = "background-color: #2E2E2E;",
          width = 7
        )
      )
    )
  )
)




server <- function(input, output) {
  
  filteredDataStreamGraph <- reactive({
    
    
    if(input$personInputMartyna == "Hleb"){
      return(gleb$stream_data)
    }
    if(input$personInputMartyna == "Martyna"){
      return(martyna$stream_data)
    }
    if(input$personInputMartyna == "Zuza"){
      return(zuza$stream_data)
    }
  })
  output$stream_plot <- renderPlot({
    p <- ggplot(filteredDataStreamGraph(), aes(endTime, count, fill = genre)) +
      geom_stream(bw = 0.5, sorting = "inside_out") +
      scale_fill_manual(values = c("#90E2ED", "#31AFD4", "#369CBB", "#406792", "#634490", "#B46F9C", "#EE5973", "#FE4E4E", "#FE7B47", "#FFA72C")) +
      theme_minimal() +
      labs(
        x = "Dzień",
        y = "Ilość odtworzeń",
        fill = "Gatunek"
      ) +
      theme(
        plot.background = element_rect(fill = "gray18", color = NA),
        panel.background = element_rect(fill = "transparent", color = NA),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.background = element_rect(fill='transparent', color = NA),
        legend.box.background = element_rect(fill='transparent', color = NA),
        legend.key = element_rect(fill = 'transparent', color = NA),
        legend.key.width = unit(1, 'cm'),
        rect = element_rect(fill = "transparent"),
        legend.position = "bottom",
        text = element_text(color = "white")
      ) +
      guides(fill = guide_legend(nrow = 2))
    
    p
    
  })
  filteredDataPackcircles <- reactive({
    
    
    if(input$personInputMartyna == "Hleb"){
      return(gleb)
    }
    if(input$personInputMartyna == "Martyna"){
      return(martyna)
    }
    if(input$personInputMartyna == "Zuza"){
      return(zuza)
    }
  })
  output$packcircles_plot <- renderGirafe({
    feature_col <- switch(input$feature,
                          "Danceability" = "Danceability",
                          "Liveness" = "Liveness",
                          "Energy" = "Energy",
                          "Valence" = "Valence")
    
    data_martyna_circles<-filteredDataPackcircles()
    data_martyna_circles$artist_data$text <- paste(data_martyna_circles$artist_data$artistName, "\n", "Liczba odtworzeń: ", data_martyna_circles$artist_data$Count, "\n", paste(input$feature, ":", data_martyna_circles$artist_data[[feature_col]]))
    
    data_martyna_circles$dat.gg[[feature_col]] <- rep(data_martyna_circles$artist_data[[feature_col]], each = 71)
    
    # Desired length of the legend title
    desired_length <- 21
    
    # Pad the legend title
    legend_title <- pad_legend_title(input$feature, desired_length)
    
    pp <- ggplot() +
      geom_polygon_interactive(
        data = data_martyna_circles$dat.gg,
        aes(x, y, group = id, fill = data_martyna_circles$dat.gg[[feature_col]],
            tooltip = data_martyna_circles$artist_data$text[id], data_id = id),
        colour = "transparent"
      ) +
      scale_fill_gradient(low = "#90E2ED", high = "#634490", limits = c(0, 1)) +  # Set breaks from 0 to 1
      geom_text(
        data = data_martyna_circles$artist_data,
        aes(x, y, size = Count,
            label = ifelse(stri_width(data_martyna_circles$artist_data$artistName) <= data_martyna_circles$artist_data$radius * 6, data_martyna_circles$artist_data$artistName, "")),
        color = "white"
      ) +
      scale_size_continuous(range = c(0.5, 3)) +
      theme_void() +
      labs(fill = legend_title) +  # Use the padded legend title
      theme(
        plot.background = element_rect(fill = "gray18", color = NA),
        panel.background = element_rect(fill = "gray18", color = NA),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        rect = element_rect(fill = "transparent"),
        legend.position = "right",
        legend.background = element_rect(fill = 'transparent', color = NA),
        legend.box.background = element_rect(fill = 'transparent', color = NA),
        legend.key = element_rect(fill = 'transparent', color = NA),
        legend.text = element_text(color = "white"),
        legend.title = element_text(color = "white")  # Add margins here
      ) +
      guides(size = FALSE) +
      coord_equal()
    
    girafe(code = print(pp),
           options = list(opts_hover(css = "fill:#EE5973;stroke:#EE5973;stroke-width:2px;")))
  })
  output$liczba_gatunkow_box <- renderValueBox({
    valueBox(
      data_box1 <- filteredDataPackcircles(),
      data_box1$liczba_gatunkow,
      "przesłuchanych gatunków",
      icon = icon("list-alt")
    )
  })
  output$liczba_gatunkow_box <- renderValueBox({
    valueBox(
      filteredDataPackcircles()$liczba_gatunkow,
      "przesłuchanych gatunków",
      icon = icon("list-alt")
    )
  })
  output$top_box <- renderValueBox({
    valueBox(
      filteredDataPackcircles()$top_genre[1],
      "Top gatunek",
      icon = icon("star")
    )
  })
  output$top_time_played_box <- renderValueBox({
    valueBox(
      paste(round(filteredDataPackcircles()$top_time_played$top_time_played,2)),
      "przesłuchanych minut ulubionego gatunku",
      icon = icon("clock")
    )
  })
  
}
shinyApp(ui = ui, server = server)
